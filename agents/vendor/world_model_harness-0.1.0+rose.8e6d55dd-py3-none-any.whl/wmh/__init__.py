"""World Model Harness — a frontier LLM acts as your agent's environment.

Public API:
    from wmh import WorldModel
    wm = WorldModel.load(".wmh", provider=...)
    session = wm.new_session(task="browse the shop")
    obs = wm.step(session.id, action)
"""

from wmh.core.types import (
    Action,
    ActionKind,
    EnvState,
    Observation,
    Session,
    Step,
    Trace,
)
from wmh.engine.world_model import WorldModel
from wmh.env import DONE_SIGNAL, Agent, Env, EpisodeResult, StopReason, WorldModelEnv, run_episode

__all__ = [
    "WorldModel",
    "Action",
    "ActionKind",
    "Observation",
    "EnvState",
    "Session",
    "Step",
    "Trace",
    "Agent",
    "DONE_SIGNAL",
    "Env",
    "EpisodeResult",
    "StopReason",
    "WorldModelEnv",
    "run_episode",
]
