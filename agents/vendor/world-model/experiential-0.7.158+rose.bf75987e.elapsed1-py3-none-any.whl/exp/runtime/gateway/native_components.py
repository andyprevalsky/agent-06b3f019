"""Structural component contracts for the native gateway control plane."""

from __future__ import annotations

from collections.abc import Mapping
from datetime import datetime
from typing import Protocol

from exp.common.models.gateway_catalog import ExactModelDeployment
from exp.runtime.gateway.contracts import (
    AttemptId,
    AuthorizationSnapshot,
    ExecutionSnapshot,
    GatewayEvent,
    GatewayFailure,
    GatewayServiceTierAdmission,
    GatewayServiceTierSettlement,
)
from exp.runtime.gateway.group_commit import GroupCommitAttemptLedger
from exp.runtime.gateway.interfaces import GatewayControlStore
from exp.runtime.gateway.routing import CatalogRouteResolver
from exp.runtime.models import RuntimeModelCatalog


class SyncWriteLedger(Protocol):
    """Synchronous durable write surface the native data plane settles through.

    Methods are called from data-plane worker threads with no event loop and
    must return only after their write is durable. The local engine satisfies
    this with the group-commit facade; a hosted store satisfies it with its
    own thread-safe synchronous ledger (for example one SQL call per method
    on a pooled connection).
    """

    def accept_request(self, *, authorization: AuthorizationSnapshot) -> None:
        """Durably accept one authorized request."""
        ...

    def start_attempt(
        self,
        *,
        snapshot: ExecutionSnapshot,
        deployment: ExactModelDeployment,
        attempt_ordinal: int,
        route_depth: int,
        maximum_cost_nano_usd: int | None = None,
        reserved_input_tokens: int | None = None,
        reserved_output_tokens: int | None = None,
        route_reason: str | None = None,
        fallback_reason: str | None = None,
        dispatch_reason: str | None = None,
        preferred_deployment: ExactModelDeployment | None = None,
        service_tier: GatewayServiceTierAdmission | None = None,
    ) -> AttemptId:
        """Durably mark one provider dispatch before network work."""
        ...

    def finish_attempt(
        self,
        *,
        attempt_id: AttemptId,
        terminal_event: GatewayEvent | None,
        failure: GatewayFailure | None,
        finalize_request: bool = True,
        first_token_at: datetime | None = None,
        retry_after_seconds: int | None = None,
        ratelimit_limit_requests: int | None = None,
        ratelimit_remaining_requests: int | None = None,
        ratelimit_limit_tokens: int | None = None,
        ratelimit_remaining_tokens: int | None = None,
        upstream_provider: str | None = None,
        web_search_requests: int = 0,
        tool_search_requests: int = 0,
        service_tier: GatewayServiceTierSettlement | None = None,
    ) -> None:
        """Durably settle one attempt exactly once.

        The ``retry_after_seconds`` and ``ratelimit_*`` values are the
        provider's own rate-limit response headers, normalized, present on
        successes and failures alike when the data plane harvested any; a
        hosted ledger persists them per attempt for calibration analytics.
        ``upstream_provider`` is the upstream an aggregator rung (OpenRouter)
        named as having served the attempt in its response metadata, so a
        zero-data-retention dispatch records which retention-free upstream
        answered; ``None`` on every rung that names none.
        ``web_search_requests`` counts the gateway-executed web searches billed
        to the attempt, never a provider meter; the hosted ledger prices them
        per attempt, and the engine omits the keyword entirely at zero.
        ``tool_search_requests`` counts the gateway-executed tool-search rounds
        billed to the attempt under the same rules: never a provider meter,
        priced by the hosted ledger, omitted entirely at zero.
        """
        ...

    def finish_request(
        self,
        *,
        authorization: AuthorizationSnapshot,
        failure: GatewayFailure,
        certify_no_effects: bool = False,
        web_search_requests: int = 0,
    ) -> bool:
        """Finalize work and certify no paid effects under the dispatch write fence.

        ``web_search_requests`` retains completed gateway searches with no model attempt.
        Persist it atomically with the failure as provider expense, without customer charge.
        Nonzero search usage must never receive a no-effects certificate.
        Certification defaults false and requires trusted admission without paid prework.
        Return true only after commit. Any prior attempt or uncertified terminal failure
        returns false; persistence failures raise instead of certifying.
        """
        ...


class NativeGatewayComponents(Protocol):
    """Engine-neutral components required by the native control plane."""

    @property
    def store(self) -> GatewayControlStore:
        """Return the authority store."""
        ...

    @property
    def ledger(self) -> SyncWriteLedger:
        """Return the synchronous durable ledger.

        The control plane reads content-free reports through this object and,
        when :attr:`write_ledger` is ``None``, also settles through it, so a
        hosted implementation must be thread-safe for data-plane callers.
        """
        ...

    @property
    def write_ledger(self) -> GroupCommitAttemptLedger | None:
        """Return the local engine's shared group-commit writer, if any.

        The local composition provides the batching writer so both engines
        share fsync batches. Hosted compositions over their own stores return
        ``None`` (or omit the attribute); the control plane then settles
        directly through :attr:`ledger`.
        """
        ...

    @property
    def batches(self) -> object | None:
        """Return the optional batch control plane serving /v1/batches.

        Hosts without the batch lane return ``None`` (or omit the attribute);
        the control plane then answers every batch route with a uniform
        not-enabled error. The returned object is a
        ``exp.runtime.gateway.batch.BatchControlPlane``; the loose annotation
        keeps the synchronous components importable without the batch package.
        """
        ...

    @property
    def routes(self) -> CatalogRouteResolver:
        """Return the direct-route resolver."""
        ...

    @property
    def accounting_healthy(self) -> bool:
        """Return whether this composition's durable accounting can still land.

        The bridge's readiness callback reads this beside its own settlement
        latch. The local composition reports its group-commit writer's
        liveness (a crashed or closed writer can no longer make any terminal
        write durable); a hosted composition reports its own store health.
        """
        ...

    @property
    def reconciled_expired_requests(self) -> int:
        """Return startup-reconciled request count."""
        ...

    @property
    def reconciled_unknown_attempts(self) -> int:
        """Return startup-reconciled attempt count."""
        ...

    @property
    def runtime_catalogs(self) -> Mapping[tuple[str, str], RuntimeModelCatalog]:
        """Return runtime catalogs keyed by alias revision and digest."""
        ...

    @property
    def organization_id(self) -> str:
        """Return the organization used by the local usage endpoint."""
        ...
