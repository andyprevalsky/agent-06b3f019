"""Deterministic standard guardrail preset expansion at configuration load."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Final

from pydantic import Field, ValidationError

from exp.common.core.artifacts import ArtifactId, ContractModel
from exp.runtime.gateway.contracts import IdentityId, OrganizationId
from exp.runtime.gateway.guardrails.contracts import (
    DEFAULT_MAX_REQUEST_BYTES,
    DEFAULT_MAX_RESPONSE_BYTES,
    GuardrailAction,
    GuardrailCapabilityKind,
    GuardrailCheck,
    GuardrailCheckStage,
    GuardrailPolicy,
)

STANDARD_PRESET_NAME: Final = "standard"
STANDARD_DEFAULT_TIMEOUT_MS: Final = 250
STANDARD_REQUIRED_CAPABILITIES: Final[frozenset[GuardrailCapabilityKind]] = frozenset(
    {
        GuardrailCapabilityKind.PII,
        GuardrailCapabilityKind.SECRET_LEAKAGE,
        GuardrailCapabilityKind.PROMPT_INJECTION,
        GuardrailCapabilityKind.CONTENT_SAFETY,
    }
)


class StandardPresetStep(ContractModel):
    """One documented check in the standard pack, in expansion order."""

    check_id: ArtifactId
    capability: GuardrailCapabilityKind
    stage: GuardrailCheckStage
    action: GuardrailAction


STANDARD_PRESET_STEPS: Final[tuple[StandardPresetStep, ...]] = (
    StandardPresetStep(
        check_id="standard-input-pii",
        capability=GuardrailCapabilityKind.PII,
        stage=GuardrailCheckStage.INPUT,
        action=GuardrailAction.MODIFY,
    ),
    StandardPresetStep(
        check_id="standard-input-secret-leakage",
        capability=GuardrailCapabilityKind.SECRET_LEAKAGE,
        stage=GuardrailCheckStage.INPUT,
        action=GuardrailAction.MODIFY,
    ),
    StandardPresetStep(
        check_id="standard-input-prompt-injection",
        capability=GuardrailCapabilityKind.PROMPT_INJECTION,
        stage=GuardrailCheckStage.INPUT,
        action=GuardrailAction.BLOCK,
    ),
    StandardPresetStep(
        check_id="standard-input-content-safety",
        capability=GuardrailCapabilityKind.CONTENT_SAFETY,
        stage=GuardrailCheckStage.INPUT,
        action=GuardrailAction.BLOCK,
    ),
    StandardPresetStep(
        check_id="standard-output-pii",
        capability=GuardrailCapabilityKind.PII,
        stage=GuardrailCheckStage.OUTPUT,
        action=GuardrailAction.MODIFY,
    ),
    StandardPresetStep(
        check_id="standard-output-secret-leakage",
        capability=GuardrailCapabilityKind.SECRET_LEAKAGE,
        stage=GuardrailCheckStage.OUTPUT,
        action=GuardrailAction.MODIFY,
    ),
    StandardPresetStep(
        check_id="standard-output-content-safety",
        capability=GuardrailCapabilityKind.CONTENT_SAFETY,
        stage=GuardrailCheckStage.OUTPUT,
        action=GuardrailAction.BLOCK,
    ),
)

STANDARD_CHECK_IDS: Final[frozenset[str]] = frozenset(
    step.check_id for step in STANDARD_PRESET_STEPS
)
_STAGE_CAPABILITY_TO_CHECK_ID: Final[dict[tuple[str, str], str]] = {
    (step.stage.value, step.capability.value): step.check_id for step in STANDARD_PRESET_STEPS
}


class AuthoredStandardPolicy(ContractModel):
    """Identity policy that opts into the documented standard pack.

    Attributes:
        policy_id: Unique operator-authored policy identity.
        organization_id: Organization that owns the identity assignment.
        identity_id: Identity within the organization that receives the pack.
        revision: Detector rollout identity, 1 to 256 characters and default configured.
            Change it when detector behavior or external rollout configuration changes.
        protected: Required explicit choice of fail-closed or fail-open inspection.
        preset: Explicit preset name, which must be standard.
        timeout_ms: Default check deadline, 250 ms within the 1 to 30,000 ms range.
        timeouts: Per-check or stage.capability deadline overrides, empty by default.
        capability_adapters: Required registered adapter identity for every capability.
        max_request_bytes: Input inspection bound, default 1 MiB and maximum 64 MiB.
        max_response_bytes: Output inspection bound, default 1 MiB and maximum 64 MiB.
    """

    policy_id: ArtifactId
    organization_id: OrganizationId
    identity_id: IdentityId
    revision: str = Field(default="configured", min_length=1, max_length=256)
    protected: bool
    preset: str
    timeout_ms: int = Field(default=STANDARD_DEFAULT_TIMEOUT_MS, ge=1, le=30_000)
    timeouts: dict[str, int] = Field(default_factory=dict)
    capability_adapters: dict[str, ArtifactId]
    max_request_bytes: int = Field(default=DEFAULT_MAX_REQUEST_BYTES, ge=1, le=64 * 1024 * 1024)
    max_response_bytes: int = Field(default=DEFAULT_MAX_RESPONSE_BYTES, ge=1, le=64 * 1024 * 1024)


def policy_from_authored(
    item: Mapping[str, object],
    adapter_ids: frozenset[str],
) -> GuardrailPolicy:
    """Validate one authored policy object and expand a preset when requested.

    The standard pack is never implied. An identity opts in by setting
    ``preset`` to ``standard``, choosing an explicit ``protected`` boolean,
    and binding every required capability to a registered ``adapter_id``.
    Presence of ``preset`` and ``checks`` together is always ambiguous,
    including an empty check list.

    Args:
        item: One policy object from ``guardrails.json``.
        adapter_ids: Adapter identities registered in the same document.

    Returns:
        An immutable policy whose checks the engine can run in order.

    Raises:
        ValueError: The object is malformed, mixed ambiguously, or unbound.
    """
    has_preset_key = "preset" in item
    has_checks_key = "checks" in item
    has_bindings_key = "capability_adapters" in item
    if has_preset_key and has_checks_key:
        raise ValueError("standard preset cannot be combined with authored checks")
    if has_bindings_key and not has_preset_key:
        raise ValueError("capability_adapters requires the standard preset")
    if "timeouts" in item and not has_preset_key:
        raise ValueError("timeouts requires the standard preset")
    if "timeout_ms" in item and not has_preset_key:
        raise ValueError("timeout_ms requires the standard preset")
    if has_preset_key:
        return _expand_standard(item, adapter_ids)
    return _manual_policy(item, adapter_ids)


def expand_standard_checks(
    *,
    capability_adapters: Mapping[str, str],
    timeout_ms: int = STANDARD_DEFAULT_TIMEOUT_MS,
    timeouts: Mapping[str, int] | None = None,
    adapter_ids: frozenset[str],
) -> tuple[GuardrailCheck, ...]:
    """Expand the standard pack into ordered checks.

    Args:
        capability_adapters: Explicit adapter identity for every capability.
        timeout_ms: Default per-check timeout used when no override is set.
        timeouts: Optional overrides keyed by check ID or ``stage.capability``.
        adapter_ids: Adapter identities that exist in the same document.

    Returns:
        The seven standard checks in documented order.

    Raises:
        ValueError: Bindings, adapters, or timeout keys are malformed.
    """
    adapters = _bound_adapters(capability_adapters, adapter_ids)
    overrides = _resolved_timeouts(timeouts or {})
    return tuple(
        GuardrailCheck(
            check_id=step.check_id,
            capability=step.capability,
            stage=step.stage,
            action=step.action,
            timeout_ms=overrides.get(step.check_id, timeout_ms),
            adapter_id=adapters[step.capability],
        )
        for step in STANDARD_PRESET_STEPS
    )


def _expand_standard(item: Mapping[str, object], adapter_ids: frozenset[str]) -> GuardrailPolicy:
    """Parse a standard-preset policy object and expand its checks."""
    preset = item.get("preset")
    if preset is None or preset == "":
        raise ValueError("preset must be standard; empty or null preset is not a manual policy")
    if "protected" not in item:
        raise ValueError("standard preset requires an explicit protected boolean")
    if "capability_adapters" not in item:
        raise ValueError("standard preset requires an adapter_id for every capability")
    try:
        authored = AuthoredStandardPolicy.model_validate(item)
    except ValidationError as exc:
        raise ValueError("standard guardrail preset is malformed") from exc
    if authored.preset != STANDARD_PRESET_NAME:
        raise ValueError("unknown guardrail preset; only standard is defined")
    checks = expand_standard_checks(
        capability_adapters=authored.capability_adapters,
        timeout_ms=authored.timeout_ms,
        timeouts=authored.timeouts,
        adapter_ids=adapter_ids,
    )
    return GuardrailPolicy(
        policy_id=authored.policy_id,
        organization_id=authored.organization_id,
        identity_id=authored.identity_id,
        revision=authored.revision,
        protected=authored.protected,
        checks=checks,
        max_request_bytes=authored.max_request_bytes,
        max_response_bytes=authored.max_response_bytes,
    )


def _manual_policy(item: Mapping[str, object], adapter_ids: frozenset[str]) -> GuardrailPolicy:
    """Parse a hand-authored policy and require every adapter to be registered."""
    try:
        authored = GuardrailPolicy.model_validate(item)
    except ValidationError as exc:
        raise ValueError("guardrail policy is malformed") from exc
    missing = sorted(
        {check.adapter_id for check in authored.checks if check.adapter_id not in adapter_ids}
    )
    if missing:
        raise ValueError(
            "guardrail checks reference unknown adapter_id values: " + ", ".join(missing)
        )
    return authored


def _bound_adapters(
    capability_adapters: Mapping[str, str],
    adapter_ids: frozenset[str],
) -> dict[GuardrailCapabilityKind, ArtifactId]:
    """Require an explicit, registered adapter for every standard capability."""
    unknown = sorted(set(capability_adapters) - {item.value for item in GuardrailCapabilityKind})
    if unknown:
        raise ValueError("unknown capability binding: " + ", ".join(unknown))
    bound: dict[GuardrailCapabilityKind, ArtifactId] = {}
    for name, adapter_id in capability_adapters.items():
        bound[GuardrailCapabilityKind(name)] = adapter_id
    missing = sorted(
        capability.value for capability in STANDARD_REQUIRED_CAPABILITIES if capability not in bound
    )
    if missing:
        raise ValueError(
            "standard preset requires an adapter_id for every capability; missing "
            + ", ".join(missing)
        )
    extra = sorted(
        capability.value for capability in bound if capability not in STANDARD_REQUIRED_CAPABILITIES
    )
    if extra:
        raise ValueError("standard preset has unexpected capability bindings: " + ", ".join(extra))
    unregistered = sorted(
        adapter_id for adapter_id in bound.values() if adapter_id not in adapter_ids
    )
    if unregistered:
        raise ValueError(
            "standard preset binds unknown adapter_id values: " + ", ".join(unregistered)
        )
    return bound


def _resolved_timeouts(timeouts: Mapping[str, int]) -> dict[str, int]:
    """Map authored timeout keys onto unique standard check IDs."""
    resolved: dict[str, int] = {}
    for key, value in timeouts.items():
        if not isinstance(value, int) or isinstance(value, bool) or value < 1 or value > 30_000:
            raise ValueError("preset timeouts must be integers from 1 to 30000")
        check_id = _timeout_check_id(key)
        if check_id in resolved:
            raise ValueError(f"ambiguous timeout override for {check_id}")
        resolved[check_id] = value
    return resolved


def _timeout_check_id(key: str) -> str:
    """Resolve one timeout key to a standard check identity."""
    if key in STANDARD_CHECK_IDS:
        return key
    if "." in key:
        stage, capability = key.split(".", 1)
        check_id = _STAGE_CAPABILITY_TO_CHECK_ID.get((stage, capability))
        if check_id is not None:
            return check_id
    raise ValueError(f"unknown standard preset timeout key: {key}")
