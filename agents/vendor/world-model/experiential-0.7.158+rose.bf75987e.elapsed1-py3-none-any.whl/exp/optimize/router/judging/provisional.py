"""Provider-free provisional judge calibration for the build wizard."""

from __future__ import annotations

from datetime import datetime

from exp.common.judging import HumanScoreReview, JudgeCalibration
from exp.common.models import ModelCatalog
from exp.common.project import ProjectStore, artifact_input
from exp.optimize.router.judging.artifacts import (
    coordinate_manual_judge_calibration,
    require_review_state,
    write_production_rollout,
    write_review_state,
)
from exp.optimize.router.judging.contracts import ManualJudgeError
from exp.optimize.router.judging.service import (
    ManualJudgeCalibrationPlan,
    find_or_bootstrap_provisional_calibration,
    write_lineage_split,
)
from exp.optimize.router.judging.setup_store import read_setup_artifact
from exp.runtime.models.registry import RuntimeModelCatalog


@coordinate_manual_judge_calibration
def bootstrap_provisional_judge(
    store: ProjectStore,
    catalog: ModelCatalog,
    plan: ManualJudgeCalibrationPlan,
    *,
    created_at: datetime,
    code_revision: str,
) -> JudgeCalibration:
    """Persist canonical zero-label judge provenance without provider work.

    Args:
        store: Project-local artifact and review store.
        catalog: Static catalog whose selected judge must match the finalized setup.
        plan: Frozen representative real-trace plan for the finalized setup.
        created_at: Time for newly materialized immutable evidence.
        code_revision: Exact producer revision for the evidence.

    Returns:
        Manifest-verified provisional calibration, including exact replay.

    Raises:
        ManualJudgeError: Setup, build, lineage, or existing review state conflicts.
    """
    state = require_review_state(store)
    if state.audit is not None or state.approved_calibration is not None:
        raise ManualJudgeError(
            "completed judge calibration cannot be replaced by provisional state"
        )
    setup = read_setup_artifact(store, state.setup)
    if setup != plan.setup:
        raise ManualJudgeError("provisional judge plan no longer matches finalized setup")
    try:
        selected_judge, _capabilities = RuntimeModelCatalog(catalog).snapshot(setup.judge_alias)
    except ValueError as exc:
        raise ManualJudgeError(str(exc)) from exc
    if selected_judge != setup.judge_model:
        raise ManualJudgeError("configured judge identity changed after finalized setup")
    rollout_inputs = tuple(
        write_production_rollout(
            store,
            setup,
            task,
            trace,
            created_at,
            code_revision,
            allow_provider_free_source=True,
        )
        for task, trace in zip(plan.tasks, plan.traces, strict=True)
    )
    split = write_lineage_split(store, setup, plan, rollout_inputs, created_at, code_revision)
    provisional = find_or_bootstrap_provisional_calibration(
        store,
        setup,
        split_id=split.split_id,
        label_review=HumanScoreReview.open(store),
        created_at=created_at,
        code_revision=code_revision,
    )
    provisional_input = artifact_input(store.artifacts.read(provisional.calibration_id).manifest)
    if state.provisional_calibration not in (None, provisional_input):
        raise ManualJudgeError("selected provisional judge calibration changed")
    write_review_state(
        store,
        state.model_copy(update={"provisional_calibration": provisional_input}),
    )
    return provisional
