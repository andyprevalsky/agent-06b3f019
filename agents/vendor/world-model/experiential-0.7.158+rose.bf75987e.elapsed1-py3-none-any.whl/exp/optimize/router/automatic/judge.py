"""Execution of the approved manual judge contract against plan-bound rollouts."""

from __future__ import annotations

import threading
from collections.abc import Callable, Iterator
from contextlib import AbstractContextManager, contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
from datetime import datetime

from exp.common.core.artifacts import ArtifactInput
from exp.common.evaluations import EvaluationPlan
from exp.common.evaluations.evidence import read_evaluation_plan, read_rollout
from exp.common.judging import Judgment, LMJudge, Rubric
from exp.common.judging.provenance import read_artifact_json
from exp.common.models import (
    CompletionCostReservation,
    ModelCapabilities,
    ModelClient,
    ModelRequest,
    ModelResponse,
    ModelSnapshot,
    OperationEconomics,
    completion_request_cost_usd,
    reconcile_completion_economics,
    verify_completion_reservation,
)
from exp.common.models.catalog_prices import GatewayTokenPrices
from exp.common.project import ProjectStore, artifact_input
from exp.common.rollouts import RolloutArtifact
from exp.optimize.router.errors import (
    JudgeDispatchExhaustedError,
    JudgePricingError,
    JudgeTranscriptAdmissionError,
)
from exp.optimize.router.judging.contracts import (
    JudgeSetupArtifact,
    ManualJudgeError,
    ManualJudgeSetupArtifact,
    ProvisionalJudgeSetupArtifact,
)
from exp.optimize.router.judging.protocol import TemplateJudgeClient
from exp.runtime.models.providers.errors import ProviderRetryableResponseError
from exp.simulation.engines.text.tokens import Utf8UpperBoundTokenCounter


@dataclass
class JudgeCallAccounting:
    """Provider activity belonging only to one judgment execution.

    Attributes:
        calls: Admitted provider requests within this scope, including failed requests.
        economics: Reconciled successful responses within this scope, in request order.
    """

    calls: int = 0
    economics: list[OperationEconomics] = field(default_factory=list)


class ReservedJudgeClient:
    """Enforce one frozen request and full-call ceiling around a judge provider."""

    def __init__(
        self,
        client: ModelClient,
        *,
        reservation: CompletionCostReservation,
        model: ModelSnapshot,
        capabilities: ModelCapabilities,
        maximum_attempts: int,
        maximum_provider_calls: int,
        served_model_id: str | None = None,
        token_prices: GatewayTokenPrices | None = None,
    ) -> None:
        """Validate active economics before exposing the provider client.

        Args:
            client: Resolved judge provider client.
            reservation: Exact approved per-request price, retry, and token ceiling.
            model: Active exact judge model identity.
            capabilities: Active explicit catalog declaration.
            maximum_attempts: Active client retry ceiling.
            maximum_provider_calls: Full scalar or counterbalanced provider-call ceiling.
            served_model_id: Explicit catalog pin for an alternate provider-reported model ID.

        Raises:
            ValueError: Pricing, model, retries, capacity, or call ceiling is invalid.
        """
        if maximum_provider_calls <= 0:
            raise ValueError("judge provider call ceiling must be positive")
        verify_completion_reservation(
            reservation,
            model=model,
            capabilities=capabilities,
            token_prices=token_prices,
            maximum_attempts=maximum_attempts,
        )
        self._client = client
        self._reservation = reservation
        self._served_model = (
            model.model_copy(update={"model_id": served_model_id})
            if served_model_id is not None
            else model
        )
        self._maximum_provider_calls = maximum_provider_calls
        self._calls = 0
        self._economics: list[OperationEconomics] = []
        self._lock = threading.Lock()
        self._accounting: ContextVar[JudgeCallAccounting | None] = ContextVar(
            "judge-call-accounting", default=None
        )
        self._counter = Utf8UpperBoundTokenCounter()

    @property
    def model(self) -> ModelSnapshot:
        """Return the provider identity verified against the frozen reservation at construction."""
        return self._reservation.model

    @property
    def calls(self) -> int:
        """Return provider requests made through this reservation boundary."""
        with self._lock:
            return self._calls

    @property
    def economics(self) -> tuple[OperationEconomics, ...]:
        """Return reconciled economics for every completed judge provider request."""
        with self._lock:
            return tuple(self._economics)

    @contextmanager
    def accounting_scope(self) -> Iterator[JudgeCallAccounting]:
        """Isolate one judgment's failure accounting from concurrently running siblings."""
        accounting = JudgeCallAccounting()
        token = self._accounting.set(accounting)
        try:
            yield accounting
        finally:
            self._accounting.reset(token)

    def complete(self, request: ModelRequest) -> ModelResponse:
        """Preflight one exact request and reconcile bounded response economics.

        Args:
            request: Complete provider-neutral judge request.

        Returns:
            Provider response with known bounded economics.

        Raises:
            JudgeTranscriptAdmissionError: The counted request input exceeds the frozen
                reserved input-token ceiling, so the rendered transcript cannot be admitted.
            JudgeDispatchExhaustedError: The admitted dispatch exhausted its bounded retries
                without usable output; the error carries the conservative billed-spend ceiling.
            ValueError: The request exceeds a bound or provider usage and spend cannot be bounded.
        """
        input_tokens = self._counter.count(request)
        output_tokens = request.maximum_output_tokens
        if output_tokens is None:
            raise ValueError("judge request must declare a maximum output-token ceiling")
        if input_tokens > self._reservation.maximum_input_tokens:
            raise JudgeTranscriptAdmissionError(
                "judge request exceeds its reserved input-token ceiling"
            )
        if output_tokens > self._reservation.maximum_output_tokens:
            raise ValueError("judge request exceeds its reserved output-token ceiling")
        accounting = self._accounting.get()
        with self._lock:
            if self._calls >= self._maximum_provider_calls:
                raise ValueError("judge provider call reservation is exhausted")
            self._calls += 1
            if accounting is not None:
                accounting.calls += 1
        try:
            response = self._client.complete(request)
        except ProviderRetryableResponseError as exc:
            raise JudgeDispatchExhaustedError(
                str(exc),
                conservative_cost_usd=completion_request_cost_usd(
                    self._reservation,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                ),
            ) from exc
        if response.model not in (self._reservation.model, self._served_model):
            raise ValueError("judge response model differs from its frozen reservation")
        pricing_error = None
        try:
            economics = reconcile_completion_economics(self._reservation, response.economics)
        except ValueError as error:
            if self._reservation.token_prices is None:
                raise
            economics = response.economics.model_copy(update={"cost_usd": None})
            pricing_error = error
        with self._lock:
            self._economics.append(economics)
            if accounting is not None:
                accounting.economics.append(economics)
        if pricing_error is not None:
            raise JudgePricingError(
                str(pricing_error),
                response=response.model_copy(update={"economics": economics, "model": self.model}),
            ) from pricing_error
        # The served pin is verified above; artifacts bind the finalized catalog identity.
        return response.model_copy(update={"economics": economics, "model": self.model})


class AutomaticRouterJudge:
    """Apply one approved setup to current-plan scalar or same-task pairwise evidence."""

    def __init__(
        self,
        client: ModelClient,
        setup: JudgeSetupArtifact,
        *,
        created_at: datetime,
        code_revision: str,
        maximum_input_tokens: int | None = None,
        maximum_output_tokens: int,
        request_scope: Callable[[str], AbstractContextManager[None]] | None = None,
    ) -> None:
        """Bind the finalized manual setup and provider boundary.

        Args:
            client: Reservation-enforcing provider client.
            setup: Finalized manual judge prompt, mapping, schema, and rubric pointer.
            created_at: Materialization time for provider probes and judgments.
            code_revision: Exact producer revision.
            maximum_input_tokens: Reserved request ceiling that rendered evidence must fit.
            maximum_output_tokens: Approved per-call output-token reservation for dispatches.
            request_scope: Optional durable request scope keyed by each finalized judge probe.
        """
        self._client = client
        self._setup = setup
        self._created_at = created_at
        self._code_revision = code_revision
        self._maximum_input_tokens = maximum_input_tokens
        self._maximum_output_tokens = maximum_output_tokens
        self._request_scope = request_scope

    @property
    def model(self) -> ModelSnapshot:
        """Expose the actual reserved provider identity for pre-dispatch evaluation checks.

        Raises:
            ManualJudgeError: The client is unbound or differs from the persisted judge setup.
        """
        if not isinstance(self._client, ReservedJudgeClient):
            raise ManualJudgeError("evaluation requires a reservation-bound judge client")
        if self._client.model != self._setup.judge_model:
            raise ManualJudgeError("reserved judge model differs from the finalized judge setup")
        return self._client.model

    @property
    def provider_economics(self) -> tuple[OperationEconomics, ...]:
        """Return completed provider economics when the reserved client records them."""
        if isinstance(self._client, ReservedJudgeClient):
            return self._client.economics
        return ()

    def judge_persisted(
        self,
        store: ProjectStore,
        *,
        rollout_artifact_id: str,
        rubric_artifact_id: str,
        calibration_artifact_id: str,
    ) -> Judgment:
        """Judge one verified current-plan rollout under the saved executable contract.

        Args:
            store: Project-local artifact store.
            rollout_artifact_id: Target rollout artifact.
            rubric_artifact_id: Approved rubric artifact.
            calibration_artifact_id: Explicitly approved calibration artifact.

        Returns:
            Unwritten judgment accepted by the shared router composition boundary.

        Raises:
            ManualJudgeError: Plan, setup, rollout, or same-task pairwise evidence is invalid.
        """
        if rubric_artifact_id != self._setup.rubric.artifact_id:
            raise ManualJudgeError("router rubric differs from the finalized judge setup")
        rollout, rollout_input = read_rollout(store.artifacts, rollout_artifact_id)
        reference, reference_input = self._reference_rollout(store, rollout)
        rubric, _rubric_input = read_artifact_json(
            store,
            artifact_id=rubric_artifact_id,
            expected_artifact_type="rubric",
            relative_path="rubric.json",
            model_type=Rubric,
        )
        adapter = TemplateJudgeClient(
            self._client,
            self._setup.prompt_template,
            rollout,
            rubric,
            reference,
            store=store,
            setup_input=_setup_input(store, self._setup),
            rollout_input=rollout_input,
            reference_input=reference_input,
            created_at=self._created_at,
            code_revision=self._code_revision,
            maximum_input_tokens=self._maximum_input_tokens,
            maximum_output_tokens=self._maximum_output_tokens,
            request_scope=self._request_scope,
        )
        return LMJudge(
            adapter,
            self._setup.prompt_template.prompt,
            code_revision=self._code_revision,
            clock=lambda: self._created_at,
            maximum_output_tokens=self._maximum_output_tokens,
        ).judge_persisted(
            store,
            rollout_artifact_id=rollout_artifact_id,
            rubric_artifact_id=rubric_artifact_id,
            calibration_artifact_id=calibration_artifact_id,
        )

    def _reference_rollout(
        self,
        store: ProjectStore,
        target: RolloutArtifact,
    ) -> tuple[RolloutArtifact | None, ArtifactInput | None]:
        """Select a distinct same-task current-plan output for pairwise feedback.

        Args:
            store: Project-local artifact store.
            target: Verified target rollout.

        Returns:
            Reference rollout and exact input, or two absent values for non-pairwise feedback.

        Raises:
            ManualJudgeError: No distinct current-plan output exists for the same task.
        """
        if self._setup.prompt_template.response_shape != "pairwise":
            return None, None
        plan = self._target_plan(store, target)
        allowed_cells = {cell.cell_id for cell in plan.cells if cell.task_id == target.task_id}
        candidates = []
        for artifact_id in store.artifacts.list_ids():
            try:
                stored = store.artifacts.read(artifact_id)
                if stored.manifest.artifact_type != "rollout":
                    continue
                rollout, rollout_input = read_rollout(store.artifacts, artifact_id)
            except (OSError, ValueError):
                continue
            if (
                rollout.rollout_id != target.rollout_id
                and rollout.task_id == target.task_id
                and rollout.cell_id in allowed_cells
            ):
                candidates.append((rollout.rollout_id, rollout, rollout_input))
        if not candidates:
            raise ManualJudgeError(
                "pairwise router judging needs a distinct completed output for the same task"
            )
        _rollout_id, reference, reference_input = min(candidates, key=lambda item: item[0])
        return reference, reference_input

    def _target_plan(self, store: ProjectStore, target: RolloutArtifact) -> EvaluationPlan:
        """Load the exact frozen evaluation plan the target rollout was simulated under.

        Args:
            store: Project-local artifact store.
            target: Verified target rollout.

        Returns:
            Verified evaluation plan named by the rollout's immutable simulation binding.

        Raises:
            ManualJudgeError: The rollout carries no binding or the persisted plan drifted.
        """
        binding = target.simulation_binding
        if binding is None:
            raise ManualJudgeError(
                "pairwise router judging needs a rollout with a simulation cell binding"
            )
        plan, plan_input = read_evaluation_plan(
            store.artifacts, binding.evaluation_plan_input.artifact_id
        )
        if plan_input != binding.evaluation_plan_input:
            raise ManualJudgeError(
                "persisted evaluation plan differs from the rollout's immutable binding"
            )
        return plan


def _setup_input(store: ProjectStore, setup: JudgeSetupArtifact) -> ArtifactInput:
    """Return the exact finalized setup pointer after identity verification.

    Args:
        store: Project-local artifact store.
        setup: Finalized setup envelope.

    Returns:
        Exact manifest pointer for the setup.

    Raises:
        ManualJudgeError: The setup envelope differs from its immutable artifact.
    """
    stored = store.artifacts.read(setup.setup_id)
    value = artifact_input(stored.manifest)
    provisional = isinstance(setup, ProvisionalJudgeSetupArtifact)
    expected_type = "provisional-judge-setup" if provisional else "manual-judge-setup"
    if stored.manifest.artifact_type != expected_type:
        raise ManualJudgeError("finalized judge setup has the wrong artifact type")
    setup_type = ProvisionalJudgeSetupArtifact if provisional else ManualJudgeSetupArtifact
    persisted = setup_type.model_validate_json(
        store.artifacts.read_bytes(setup.setup_id, "setup.json")
    )
    if persisted != setup:
        raise ManualJudgeError("finalized judge setup differs from its immutable artifact")
    return value
