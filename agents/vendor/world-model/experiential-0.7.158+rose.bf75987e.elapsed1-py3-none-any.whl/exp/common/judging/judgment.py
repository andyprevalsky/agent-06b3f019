"""Canonical immutable judgment contracts for existing rollout evidence."""

from __future__ import annotations

import math

from pydantic import Field, field_validator, model_validator

from exp.common.core.artifacts import ArtifactEnvelope, ArtifactId, ContractModel, Sha256
from exp.common.models import ModelSnapshot, OperationEconomics


class DimensionJudgment(ContractModel):
    """A judge's raw and calibrated assessment of one rubric axis.

    Retired citation-era fields such as ``feedback`` and ``evidence_span_ids``
    are rejected. Rebuild the judgment under the current rationale-only contract.

    Attributes:
        dimension_id: Identity of the rubric axis being scored.
        raw_score: Signed integer inside the inclusive axis range.
        calibrated_score: Finite calibrated value inside the same range.
        min_score: Inclusive lower bound, strictly below max_score.
        max_score: Inclusive upper bound.
        rationale: Optional explanation of the judgment, defaulting to None.
    """

    dimension_id: ArtifactId
    raw_score: int
    calibrated_score: float
    min_score: int
    max_score: int
    rationale: str | None = None

    @field_validator("calibrated_score")
    @classmethod
    def _require_finite_score(cls, value: float) -> float:
        if not math.isfinite(value):
            raise ValueError("calibrated_score must be finite")
        return value

    @model_validator(mode="after")
    def _require_score_inside_axis_range(self) -> DimensionJudgment:
        """Require both observations to stay within a nondegenerate signed axis."""
        if self.min_score >= self.max_score:
            raise ValueError("dimension judgment range must have min_score below max_score")
        if self.raw_score < self.min_score or self.raw_score > self.max_score:
            raise ValueError("raw_score must be an integer inside the axis range")
        if self.calibrated_score < self.min_score or self.calibrated_score > self.max_score:
            raise ValueError("calibrated_score must stay inside the axis range")
        return self

    def normalize_score(self) -> float:
        """Map the calibrated axis score onto the unit interval."""
        return (self.calibrated_score - self.min_score) / (self.max_score - self.min_score)


class Judgment(ArtifactEnvelope):
    """A frozen score of one rollout under one rubric and calibration."""

    judgment_id: ArtifactId
    rollout_id: ArtifactId
    rubric_id: ArtifactId
    calibration_id: ArtifactId
    judge_model: ModelSnapshot
    judge_prompt_id: str = Field(min_length=1, max_length=256)
    judge_prompt_sha256: Sha256
    dimensions: tuple[DimensionJudgment, ...]
    overall_score: float = Field(ge=0, le=1)
    judge_economics: OperationEconomics | None = None

    @field_validator("dimensions")
    @classmethod
    def _require_unique_dimensions(
        cls, value: tuple[DimensionJudgment, ...]
    ) -> tuple[DimensionJudgment, ...]:
        if not value:
            raise ValueError("a judgment must score at least one rubric axis")
        dimension_ids = tuple(dimension.dimension_id for dimension in value)
        if len(set(dimension_ids)) != len(dimension_ids):
            raise ValueError("judgments must not repeat a rubric axis")
        return value

    @field_validator("overall_score")
    @classmethod
    def _require_finite_overall_score(cls, value: float) -> float:
        if not math.isfinite(value):
            raise ValueError("overall_score must be finite")
        return value

    @model_validator(mode="after")
    def _require_equal_weight_overall_score(self) -> Judgment:
        expected_score = sum(dimension.normalize_score() for dimension in self.dimensions) / len(
            self.dimensions
        )
        if not math.isclose(self.overall_score, expected_score, rel_tol=1e-12, abs_tol=1e-12):
            raise ValueError("overall_score must equal the equal-weight calibrated axis mean")
        return self
