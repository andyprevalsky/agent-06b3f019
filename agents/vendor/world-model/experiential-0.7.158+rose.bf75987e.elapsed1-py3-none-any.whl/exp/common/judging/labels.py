"""Append-only human score and correction-history contracts for calibration."""

from __future__ import annotations

from collections.abc import Callable
from datetime import datetime

from pydantic import AwareDatetime, JsonValue, model_validator

from exp.common.core.artifacts import (
    ArtifactEnvelope,
    ArtifactId,
    ContractModel,
    JsonObject,
    canonical_json_bytes,
    stable_id,
)
from exp.common.judging.provenance import JudgingProvenanceError, read_artifact_json
from exp.common.judging.rubric import Rubric
from exp.common.project import (
    ArtifactCorruptionError,
    ProjectStore,
    coordinate_completed_build_selection,
)


class HumanScore(ContractModel):
    """One immutable human rating, optionally correcting an earlier rating.

    Attributes:
        label_id: Unique identity of this label revision.
        rubric_id: Immutable rubric defining the score range.
        rollout_id: Rollout assessed by the reviewer.
        lineage_id: Source lineage used to separate fit and held-out evidence.
        dimension_id: Scored rubric axis.
        score: Signed integer checked against the axis before persistence.
        created_at: Timezone-aware time the reviewer authored this score.
        supersedes_label_id: Earlier active label being corrected, or None for a new label.
    """

    label_id: ArtifactId
    rubric_id: ArtifactId
    rollout_id: ArtifactId
    lineage_id: ArtifactId
    dimension_id: ArtifactId
    score: int
    created_at: AwareDatetime
    supersedes_label_id: ArtifactId | None = None


class HumanScoreHistory(ContractModel):
    """An append-only label history whose active scores retain every correction."""

    scores: tuple[HumanScore, ...] = ()

    @model_validator(mode="after")
    def _require_linear_correction_history(self) -> HumanScoreHistory:
        known: dict[str, HumanScore] = {}
        superseded: set[str] = set()
        active_by_target: dict[tuple[str, str, str, str], str] = {}
        for score in self.scores:
            if score.label_id in known:
                raise ValueError("human score history label IDs must not repeat")
            target = _target_key(score)
            if score.supersedes_label_id is not None:
                prior = known.get(score.supersedes_label_id)
                if prior is None:
                    raise ValueError("human score corrections must reference an earlier label")
                if prior.label_id in superseded:
                    raise ValueError("human score labels can have only one direct correction")
                if _target_key(prior) != _target_key(score):
                    raise ValueError("human score corrections must keep the same rollout and scale")
                if active_by_target.get(target) != prior.label_id:
                    raise ValueError("human score corrections must supersede the active label")
                superseded.add(prior.label_id)
            elif target in active_by_target:
                raise ValueError(
                    "new human scores must correct an existing active rollout and scale"
                )
            known[score.label_id] = score
            active_by_target[target] = score.label_id
        return self

    def active_scores(self) -> tuple[HumanScore, ...]:
        """Return the current label for each rollout and rubric dimension.

        Returns:
            Every history entry that has not been superseded by a later correction.
        """
        superseded = {
            score.supersedes_label_id
            for score in self.scores
            if score.supersedes_label_id is not None
        }
        return tuple(score for score in self.scores if score.label_id not in superseded)

    def append(self, score: HumanScore) -> HumanScoreHistory:
        """Return a new history with one original human score appended.

        Args:
            score: New score that must not supersede an existing label.

        Returns:
            A validated append-only history with the supplied score at its end.

        Raises:
            ValueError: The supplied score is expressed as a correction.
        """
        if score.supersedes_label_id is not None:
            raise ValueError("append accepts original labels; use correct for a correction")
        return HumanScoreHistory(scores=(*self.scores, score))

    def correct(self, score: HumanScore) -> HumanScoreHistory:
        """Return a new history with one correction appended.

        Args:
            score: New score that explicitly supersedes an earlier active label.

        Returns:
            A validated append-only history retaining both the old and new labels.

        Raises:
            ValueError: The supplied score does not declare a predecessor.
        """
        if score.supersedes_label_id is None:
            raise ValueError("correct requires supersedes_label_id")
        return HumanScoreHistory(scores=(*self.scores, score))

    def for_rubric(self, rubric_id: ArtifactId) -> HumanScoreHistory:
        """Return this complete correction history restricted to one rubric version.

        Args:
            rubric_id: Immutable rubric whose labels should be frozen for calibration.

        Returns:
            An append-only history containing only labels for the requested rubric.
        """
        return HumanScoreHistory(
            scores=tuple(score for score in self.scores if score.rubric_id == rubric_id)
        )


def _target_key(score: HumanScore) -> tuple[str, str, str, str]:
    """Return the stable target of a human rubric label."""
    return (score.rubric_id, score.rollout_id, score.lineage_id, score.dimension_id)


class HumanLabelSet(ArtifactEnvelope):
    """Immutable append-only human-label history frozen for one rubric calibration."""

    label_set_id: ArtifactId
    rubric_id: ArtifactId
    history: HumanScoreHistory
    active_label_ids: tuple[ArtifactId, ...]

    @model_validator(mode="after")
    def _require_consistent_history(self) -> HumanLabelSet:
        if tuple(item.artifact_id for item in self.inputs) != (self.rubric_id,):
            raise ValueError("human label sets must hash exactly their finalized rubric")
        if any(score.rubric_id != self.rubric_id for score in self.history.scores):
            raise ValueError("human label sets must contain labels for one rubric")
        expected_active_ids = tuple(score.label_id for score in self.history.active_scores())
        if self.active_label_ids != expected_active_ids:
            raise ValueError("human label sets must list exactly their active label IDs")
        return self


class HumanScoreReview:
    """Persist append-only human-score history inside the sole mutable project review draft."""

    def __init__(
        self, store: ProjectStore, root_review: JsonObject, history: HumanScoreHistory
    ) -> None:
        """Construct the history service from validated review-draft state."""
        self._store = store
        self._root_review = root_review
        self._history = history

    @classmethod
    def open(cls, store: ProjectStore) -> HumanScoreReview:
        """Create or resume the append-only human score history for one project.

        Args:
            store: Project-local storage containing the sole mutable review JSON file.

        Returns:
            A history service whose every append preserves all prior labels.

        Raises:
            ValueError: The saved review data is not a valid JSON object or score history.
        """
        selected: list[tuple[JsonObject, HumanScoreHistory]] = []

        def initialize(current: JsonValue | None) -> JsonObject:
            """Seed the persisted review namespace with its current score history."""
            root = root_review_object(current)
            history = _history_from_root(root)
            root["human_score_history"] = history.model_dump(mode="json")
            selected.append((root, history))
            return root

        with coordinate_completed_build_selection(store):
            store.update_review(initialize)
        root, history = selected[0]
        return cls(store, root, history)

    @property
    def history(self) -> HumanScoreHistory:
        """Return the complete append-only score and correction history."""
        return self._history

    def append(self, score: HumanScore) -> None:
        """Persist one original human score without modifying prior labels.

        Args:
            score: New score with no correction predecessor.
        """
        self._mutate(lambda history: history.append(score), rubric_id=score.rubric_id, score=score)

    def correct(self, score: HumanScore) -> None:
        """Persist one correction while retaining its superseded historical label.

        Args:
            score: New score that names the earlier label it supersedes.
        """
        self._mutate(lambda history: history.correct(score), rubric_id=score.rubric_id, score=score)

    def upsert(
        self,
        *,
        rubric_id: ArtifactId,
        rollout_id: ArtifactId,
        lineage_id: ArtifactId,
        dimension_id: ArtifactId,
        score: int,
        submission_id: str,
        created_at: datetime,
    ) -> HumanScore:
        """Append or correct one score with a stable client delivery identity under the lock.

        Args:
            rubric_id: Immutable finalized rubric that owns the score.
            rollout_id: Persisted rollout receiving the score.
            lineage_id: Frozen task lineage retained for calibration.
            dimension_id: Rubric axis receiving the score.
            score: Human score on the finalized axis range.
            submission_id: Stable identifier for this one UI submission and all of its retries.
            created_at: Time at which the local human decision is recorded.

        Returns:
            The stored original score, immutable correction, or existing identical score.

        Raises:
            ValueError: The supplied submission identity is empty, or score timestamp has no
                timezone.
        """
        if created_at.tzinfo is None or created_at.utcoffset() is None:
            raise ValueError("human score timestamps must include a timezone")
        if not submission_id.strip():
            raise ValueError("human score submission IDs must be nonempty")
        result: list[HumanScore] = []

        def update(current: JsonValue | None) -> JsonObject:
            """Append or replay one idempotent score submission in the review namespace."""
            root = root_review_object(current)
            history = _history_from_root(root)
            submissions = _score_submissions_from_root(root)
            target = (rubric_id, rollout_id, lineage_id, dimension_id)
            saved_label_id = submissions.get(submission_id)
            if saved_label_id is not None:
                saved = next(
                    (item for item in history.scores if item.label_id == saved_label_id),
                    None,
                )
                if saved is None:
                    raise ValueError("human score submission refers to a missing label")
                if _target_key(saved) != target or saved.score != score:
                    raise ValueError(
                        "human score submission IDs cannot be reused for a different decision"
                    )
                result.append(saved)
                selected.append((root, history))
                return root
            existing = next(
                (
                    item
                    for item in history.active_scores()
                    if (
                        item.rubric_id,
                        item.rollout_id,
                        item.lineage_id,
                        item.dimension_id,
                    )
                    == (rubric_id, rollout_id, lineage_id, dimension_id)
                ),
                None,
            )
            if existing is not None and existing.score == score:
                label = existing
                next_history = history
            else:
                label = HumanScore(
                    label_id=stable_id(
                        "human-score",
                        {
                            "rubric_id": rubric_id,
                            "rollout_id": rollout_id,
                            "lineage_id": lineage_id,
                            "dimension_id": dimension_id,
                            "score": score,
                            "sequence": len(history.scores),
                        },
                    ),
                    rubric_id=rubric_id,
                    rollout_id=rollout_id,
                    lineage_id=lineage_id,
                    dimension_id=dimension_id,
                    score=score,
                    created_at=created_at,
                    supersedes_label_id=None if existing is None else existing.label_id,
                )
                next_history = history.append(label) if existing is None else history.correct(label)
            submissions[submission_id] = label.label_id
            result.append(label)
            root["human_score_history"] = next_history.model_dump(mode="json")
            root["human_score_submissions"] = submissions
            selected.append((root, next_history))
            return root

        selected: list[tuple[JsonObject, HumanScoreHistory]] = []
        with coordinate_completed_build_selection(self._store):
            _require_rubric_matches_selected_build(self._store, rubric_id)
            _require_score_on_rubric_axis(
                self._store,
                rubric_id=rubric_id,
                dimension_id=dimension_id,
                score=score,
            )
            self._store.update_review(update)
        self._root_review, self._history = selected[0]
        return result[0]

    def finalize(
        self,
        *,
        rubric_id: ArtifactId,
        code_revision: str,
        created_at: datetime,
    ) -> HumanLabelSet:
        """Freeze the latest locked score history as an immutable calibration input.

        Args:
            rubric_id: Immutable finalized rubric whose labels are being frozen.
            code_revision: Exact code revision producing the label-set artifact.
            created_at: Time at which the frozen label set is materialized.

        Returns:
            The immutable label set containing the complete correction history.
        """
        result: list[HumanLabelSet] = []

        def transition(history: HumanScoreHistory) -> HumanScoreHistory:
            """Freeze the latest persisted history into one immutable label set."""
            self._history = history
            result.append(
                self._finalize(
                    rubric_id=rubric_id,
                    code_revision=code_revision,
                    created_at=created_at,
                )
            )
            return history

        self._mutate(transition, rubric_id=rubric_id)
        return result[0]

    def _finalize(
        self,
        *,
        rubric_id: ArtifactId,
        code_revision: str,
        created_at: datetime,
    ) -> HumanLabelSet:
        """Freeze one rubric-specific label history as an immutable calibration input.

        Args:
            rubric_id: Immutable rubric whose human labels should be frozen.
            code_revision: Exact code revision producing the label-set artifact.
            created_at: Time the frozen set is materialized.

        Returns:
            The immutable label-set artifact containing full correction history and active labels.

        Raises:
            ValueError: The supplied finalization time has no timezone.
        """
        if created_at.tzinfo is None or created_at.utcoffset() is None:
            raise ValueError("human label-set times must include a timezone")
        try:
            rubric, rubric_input = read_artifact_json(
                self._store,
                artifact_id=rubric_id,
                expected_artifact_type="rubric",
                relative_path="rubric.json",
                model_type=Rubric,
            )
        except JudgingProvenanceError as exc:
            raise ValueError(
                "human label sets require a completed immutable finalized rubric"
            ) from exc
        if rubric.rubric_id != rubric_id:
            raise ValueError("stored rubric record does not match its artifact identity")
        history = self._history.for_rubric(rubric_id)
        for label in history.scores:
            if not rubric.axis(label.dimension_id).contains_score(label.score):
                raise ValueError("human label history contains a score outside its rubric axis")
        label_set = HumanLabelSet(
            schema_version=1,
            created_at=created_at,
            inputs=(rubric_input,),
            code_revision=code_revision,
            label_set_id=stable_id(
                "human-label-set",
                {
                    "rubric_id": rubric_id,
                    "history": history.model_dump(mode="json"),
                    "inputs": [rubric_input.model_dump(mode="json")],
                },
            ),
            rubric_id=rubric_id,
            history=history,
            active_label_ids=tuple(score.label_id for score in history.active_scores()),
        )
        try:
            stored, _ = self._store.artifacts.write_or_replay(
                artifact_id=label_set.label_set_id,
                artifact_type="human-label-set",
                envelope=label_set,
                envelope_path="labels.json",
                envelope_type=HumanLabelSet,
                files={"labels.json": canonical_json_bytes(label_set)},
            )
        except ArtifactCorruptionError as exc:
            raise ValueError("existing human label-set artifact cannot be resumed safely") from exc
        except ValueError as exc:
            raise ValueError(
                "existing human label-set artifact conflicts with this review"
            ) from exc
        return stored

    def _mutate(
        self,
        transition: Callable[[HumanScoreHistory], HumanScoreHistory],
        *,
        rubric_id: ArtifactId,
        score: HumanScore | None = None,
    ) -> None:
        """Apply one score transition while build selection and review state are locked.

        Args:
            transition: Pure history transition to apply to the latest persisted namespace.
            rubric_id: Immutable rubric whose source task set must remain selected.
            score: New label whose axis bounds must be checked before mutation.
        """
        selected: list[tuple[JsonObject, HumanScoreHistory]] = []

        def update(current: JsonValue | None) -> JsonObject:
            """Apply the caller's history transition to the latest persisted namespace."""
            root = root_review_object(current)
            history = transition(_history_from_root(root))
            root["human_score_history"] = history.model_dump(mode="json")
            selected.append((root, history))
            return root

        with coordinate_completed_build_selection(self._store):
            _require_rubric_matches_selected_build(self._store, rubric_id)
            if score is not None:
                _require_score_on_rubric_axis(
                    self._store,
                    rubric_id=rubric_id,
                    dimension_id=score.dimension_id,
                    score=score.score,
                )
            self._store.update_review(update)
        self._root_review, self._history = selected[0]


def _require_rubric_matches_selected_build(
    store: ProjectStore,
    rubric_id: ArtifactId,
) -> None:
    """Reject a score writer whose rubric belongs to an older selected task set.

    Args:
        store: Project whose completed build is stable under the caller's coordination lock.
        rubric_id: Immutable rubric used by the score transition.

    Raises:
        ValueError: The rubric is unavailable or names a task set other than the selected build.
    """
    completed = store.load_project().build
    if completed is None:
        return
    try:
        rubric, _rubric_input = read_artifact_json(
            store,
            artifact_id=rubric_id,
            expected_artifact_type="rubric",
            relative_path="rubric.json",
            model_type=Rubric,
        )
    except JudgingProvenanceError as exc:
        raise ValueError("human scores require a completed immutable finalized rubric") from exc
    if rubric.source_task_set_id != completed.task_set.artifact_id:
        raise ValueError(
            "human score rubric differs from the selected completed build; reopen labels from "
            "the current project build"
        )


def _require_score_on_rubric_axis(
    store: ProjectStore,
    *,
    rubric_id: ArtifactId,
    dimension_id: ArtifactId,
    score: int,
) -> None:
    """Reject a human score that is not an integer on the named rubric axis.

    Args:
        store: Project whose finalized rubric is already selected.
        rubric_id: Immutable rubric that owns the axis.
        dimension_id: Axis receiving the score.
        score: Proposed human score.

    Raises:
        ValueError: The axis is missing or the score is outside its inclusive range.
    """
    try:
        rubric, _rubric_input = read_artifact_json(
            store,
            artifact_id=rubric_id,
            expected_artifact_type="rubric",
            relative_path="rubric.json",
            model_type=Rubric,
        )
    except JudgingProvenanceError as exc:
        raise ValueError("human scores require a completed immutable finalized rubric") from exc
    axis = rubric.axis(dimension_id)
    if not axis.contains_score(score):
        raise ValueError(
            f"human scores for {dimension_id} must be integers from {axis.min_score} through "
            f"{axis.max_score}"
        )


def root_review_object(
    review: JsonValue | None, *, error_type: type[Exception] = ValueError
) -> JsonObject:
    """Validate one locked review value as an object for namespace-preserving updates.

    Args:
        review: Current `review.json` value held under the project write lock.
        error_type: Domain error raised when the value is not a string-keyed object.

    Returns:
        The review namespace, empty when the file does not exist yet.

    Raises:
        Exception: `error_type` when the value is not an object with string field names.
    """
    if review is None:
        return {}
    if not isinstance(review, dict):
        raise error_type("review.json must be a JSON object")
    root: JsonObject = {}
    for key, value in review.items():
        if not isinstance(key, str):
            raise error_type("review.json must use string field names")
        root[key] = value
    return root


def _history_from_root(root: JsonObject) -> HumanScoreHistory:
    """Validate the score namespace from the latest locked review root."""
    saved = root.get("human_score_history")
    if saved is None:
        return HumanScoreHistory()
    try:
        return HumanScoreHistory.model_validate(saved)
    except ValueError as exc:
        raise ValueError("review.json contains an invalid human score history") from exc


def _score_submissions_from_root(root: JsonObject) -> dict[str, str]:
    """Validate the local retry map from a locked review root."""
    saved = root.get("human_score_submissions")
    if saved is None:
        return {}
    if not isinstance(saved, dict) or any(
        not isinstance(submission_id, str)
        or not submission_id
        or not isinstance(label_id, str)
        or not label_id
        for submission_id, label_id in saved.items()
    ):
        raise ValueError("review.json contains an invalid human score submission map")
    return dict(saved)
