"""Collection-first model catalog setup with atomic, secret-free updates."""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Literal

from pydantic import Field, SerializerFunctionWrapHandler, model_serializer, model_validator

from exp.common.core.artifacts import ContractModel
from exp.common.core.locks import file_write_lock
from exp.common.models.bedrock_connection import require_bedrock_connection_shape
from exp.common.models.catalog import (
    MODEL_CATALOG_SCHEMA_VERSION,
    ConnectionConfig,
    ModelCatalog,
    ModelRecord,
    ModelRoles,
    load_model_catalog,
    write_model_catalog,
)
from exp.common.models.discovery import DiscoveredModel
from exp.common.models.model import BillingSource, ModelCapabilities, ReasoningEffort

SETUP_PROVIDERS = frozenset(
    {
        "anthropic",
        "azure",
        "bedrock",
        "gemini",
        "openai",
        "openai-compatible",
        "openrouter",
        "typesafe",
        "vertex",
    }
)


class ProviderSetupError(ValueError):
    """Provider setup cannot be applied without replacing or losing catalog state."""


class ProviderConnection(ContractModel):
    """One named, secret-free provider connection collected during setup."""

    name: str = Field(min_length=1, max_length=128)
    provider: str = Field(min_length=1, max_length=128)
    api_key_env: str | None = Field(default=None, max_length=256)
    base_url: str | None = Field(default=None, max_length=2_048)
    api_version: str | None = Field(default=None, max_length=64)
    azure_api_surface: Literal["openai_deployments", "model_inference"] | None = None
    region: str | None = Field(default=None, max_length=64)
    aws_access_key_id_env: str | None = Field(default=None, max_length=256)
    bedrock_auth_mode: Literal["access_key_pair", "api_key"] | None = None
    # Opt-in: route a native provider through a trusted custom base_url in its
    # own dialect (mirrors ConnectionConfig.trusted_custom_origin).
    trusted_custom_origin: bool = False

    @model_validator(mode="after")
    def _require_supported_connection_shape(self) -> ProviderConnection:
        if self.provider != "bedrock" and (
            self.aws_access_key_id_env is not None or self.bedrock_auth_mode is not None
        ):
            raise ValueError(
                "aws_access_key_id_env and bedrock_auth_mode are only accepted for "
                "provider='bedrock'"
            )
        if self.provider not in SETUP_PROVIDERS:
            choices = ", ".join(sorted(SETUP_PROVIDERS))
            raise ValueError(f"provider must be one of: {choices}")
        if self.provider == "openai-compatible" and self.base_url is None:
            raise ValueError("openai-compatible requires an explicit base_url")
        if self.provider == "azure":
            if self.base_url is None:
                raise ValueError("azure requires an explicit resource endpoint in base_url")
            if self.api_key_env is None:
                raise ValueError("azure requires api_key_env")
            if self.api_version is None:
                raise ValueError("azure requires an explicit api_version")
        elif self.provider == "bedrock":
            require_bedrock_connection_shape(
                bedrock_auth_mode=self.bedrock_auth_mode,
                api_key_env=self.api_key_env,
                aws_access_key_id_env=self.aws_access_key_id_env,
                base_url=self.base_url,
                api_version=self.api_version,
            )
        elif self.provider == "vertex":
            if self.base_url is None:
                raise ValueError("vertex requires an explicit project-and-location base_url")
            if self.api_key_env is None:
                raise ValueError(
                    "vertex requires api_key_env naming the service-account JSON credential"
                )
            if self.api_version is not None:
                raise ValueError("api_version is only accepted for provider='azure'")
            if self.region is not None:
                raise ValueError("region is only accepted for provider='bedrock'")
        else:
            if self.api_key_env is None:
                raise ValueError(f"{self.provider} requires api_key_env")
            if (
                self.base_url is not None
                and self.provider != "openai-compatible"
                and not self.trusted_custom_origin
            ):
                raise ValueError(
                    "base_url is only accepted for provider='openai-compatible' or "
                    "provider='azure'; set trusted_custom_origin to route a native provider "
                    "through a trusted custom endpoint"
                )
            if self.api_version is not None:
                raise ValueError("api_version is only accepted for provider='azure'")
            if self.region is not None:
                raise ValueError("region is only accepted for provider='bedrock'")
        ConnectionConfig(
            provider=self.provider,
            base_url=self.base_url,
            api_key_env=self.api_key_env,
            api_version=self.api_version,
            azure_api_surface=self.azure_api_surface,
            region=self.region,
            aws_access_key_id_env=self.aws_access_key_id_env,
            bedrock_auth_mode=self.bedrock_auth_mode,
            trusted_custom_origin=self.trusted_custom_origin,
        )
        return self

    def catalog_config(self) -> ConnectionConfig:
        """Return the validated catalog connection represented by this input."""
        return ConnectionConfig(
            provider=self.provider,
            base_url=self.base_url,
            api_key_env=self.api_key_env,
            api_version=self.api_version,
            azure_api_surface=self.azure_api_surface,
            region=self.region,
            aws_access_key_id_env=self.aws_access_key_id_env,
            bedrock_auth_mode=self.bedrock_auth_mode,
            trusted_custom_origin=self.trusted_custom_origin,
        )

    @model_serializer(mode="wrap")
    def _serialize_without_absent_bedrock_metadata(
        self,
        handler: SerializerFunctionWrapHandler,
    ) -> dict[str, object]:
        """Preserve legacy setup payload bytes without requiring Pydantic 2.12."""
        serialized: dict[str, object] = handler(self)
        if self.aws_access_key_id_env is None:
            serialized.pop("aws_access_key_id_env", None)
        if self.bedrock_auth_mode is None:
            serialized.pop("bedrock_auth_mode", None)
        if not self.trusted_custom_origin:
            serialized.pop("trusted_custom_origin", None)
        return serialized


class ProviderModelSelection(ContractModel):
    """One stable alias and exact provider-side model selected during setup.

    ``served_model_id`` optionally pins the provider-reported response identity when the
    endpoint reports a served-model name that differs from the requested model ID.

    Attributes:
        supported_reasoning_efforts: Discovery choices retained for future setup screens.
        discovery: Published flags and prices retained without losing explicit false values.
    """

    alias: str = Field(min_length=1, max_length=128)
    connection: str = Field(min_length=1, max_length=128)
    model: str = Field(min_length=1, max_length=2_048)
    served_model_id: str | None = Field(default=None, min_length=1, max_length=2_048)
    billing_source: BillingSource = BillingSource.CUSTOMER_MANAGED
    capabilities: ModelCapabilities = Field(default_factory=ModelCapabilities)
    supported_reasoning_efforts: tuple[ReasoningEffort, ...] | None = None
    discovery: DiscoveredModel | None = None

    @model_validator(mode="after")
    def _require_explicit_prices(self) -> ProviderModelSelection:
        """Require every price needed by each declared request protocol.

        Returns:
            The validated model selection.

        Raises:
            ValueError: An embedding or completion price required by a declared protocol is absent.
        """
        caps = self.capabilities
        if (
            caps.supports_embeddings or caps.supports_completions
        ) and caps.input_cost_per_million_tokens_usd is None:
            raise ValueError(
                "embedding- or completion-capable models require explicit input cost per "
                "million tokens; "
                "use 0 for a model with no input charge"
            )
        if caps.supports_completions:
            missing = tuple(
                name
                for name, value in (
                    ("output", caps.output_cost_per_million_tokens_usd),
                    ("cached input", caps.cached_input_cost_per_million_tokens_usd),
                    ("cache write", caps.cache_write_cost_per_million_tokens_usd),
                )
                if value is None
            )
            if missing:
                raise ValueError(
                    "completion-capable models require explicit "
                    + ", ".join(missing)
                    + " cost per million tokens; use 0 for an unsupported or free cache path"
                )
        return self

    def catalog_record(self) -> ModelRecord:
        """Return the exact catalog record represented by this selection.

        Returns:
            Model-catalog entry that preserves connection, model ID, and capabilities.
        """
        return ModelRecord(
            connection=self.connection,
            model=self.model,
            served_model_id=self.served_model_id,
            billing_source=self.billing_source,
            capabilities=self.capabilities,
            supported_reasoning_efforts=self.supported_reasoning_efforts,
            discovery=self.discovery,
        )


class ProviderSetup(ContractModel):
    """Collected connections, available model aliases, and independent build roles."""

    connections: tuple[ProviderConnection, ...] = ()
    models: tuple[ProviderModelSelection, ...] = ()
    known_existing_connections: tuple[str, ...] = ()
    known_existing_aliases: tuple[str, ...] = ()
    world_model: str = Field(min_length=1, max_length=128)
    judge: str = Field(min_length=1, max_length=128)
    embedder: str = Field(min_length=1, max_length=128)
    world_model_reasoning_effort: ReasoningEffort | None = None
    judge_reasoning_effort: ReasoningEffort | None = None

    @model_validator(mode="after")
    def _require_unique_references_and_role_capabilities(self) -> ProviderSetup:
        """Validate collected identities and the three independently selected roles.

        Returns:
            The complete validated provider setup.

        Raises:
            ValueError: Connections, aliases, references, or role capabilities are invalid.
        """
        connection_names = tuple(connection.name for connection in self.connections)
        if len(set(connection_names)) != len(connection_names):
            raise ValueError("provider connection names must be unique")
        aliases = tuple(model.alias for model in self.models)
        if len(set(aliases)) != len(aliases):
            raise ValueError("provider model aliases must be unique")
        known_connections = set(connection_names).union(self.known_existing_connections)
        if not known_connections:
            raise ValueError("provider setup needs at least one available connection")
        if not set(aliases).union(self.known_existing_aliases):
            raise ValueError("provider setup needs at least one available model alias")
        unknown_connections = {
            model.connection for model in self.models if model.connection not in known_connections
        }
        if unknown_connections:
            raise ValueError(
                "model aliases name unknown connections: " + ", ".join(sorted(unknown_connections))
            )
        known_aliases = set(aliases).union(self.known_existing_aliases)
        unknown_roles = {self.world_model, self.judge, self.embedder}.difference(known_aliases)
        if unknown_roles:
            raise ValueError(
                "build roles name unknown model aliases: " + ", ".join(sorted(unknown_roles))
            )
        by_alias = {model.alias: model for model in self.models}
        selected = by_alias.get(self.embedder)
        if selected is not None and not selected.capabilities.supports_embeddings:
            raise ValueError(f"embedder alias {self.embedder!r} must declare embedding support")
        return self


def catalog_state_sha256(path: Path) -> str:
    """Return the exact catalog-file digest, or the empty-state digest when absent.

    Args:
        path: Shared model-catalog path.

    Returns:
        SHA-256 digest of the current bytes or the canonical empty state.
    """
    try:
        payload = path.read_bytes()
    except FileNotFoundError:
        payload = b""
    return hashlib.sha256(payload).hexdigest()


def configure_provider_catalog(
    path: Path,
    setup: ProviderSetup,
    *,
    replace: bool = False,
    expected_state_sha256: str | None = None,
) -> ModelCatalog:
    """Atomically merge collected connections, model aliases, and build roles.

    Existing unrelated aliases and router candidate assignments are preserved. The optional
    expected digest protects a prompt session from overwriting catalog edits made while answers
    were being collected.

    Args:
        path: Local ``.exp/models.toml`` path.
        setup: Fully collected connections, model aliases, and role selections.
        replace: Whether conflicting collected entries may be replaced.
        expected_state_sha256: Exact catalog state observed before interactive collection.

    Returns:
        The complete validated catalog written to ``path``.

    Raises:
        ProviderSetupError: Existing state conflicts, changed, or protects a router candidate.
        ModelCatalogError: Existing catalog content is invalid.
    """
    with file_write_lock(path, what="provider model configuration"):
        current_state = catalog_state_sha256(path)
        if expected_state_sha256 is not None and current_state != expected_state_sha256:
            raise ProviderSetupError(
                "models.toml changed while setup was in progress; review the new catalog and retry"
            )
        existing = load_model_catalog(path) if path.exists() else None
        catalog = _merge_provider_setup(existing, setup, replace=replace)
        write_model_catalog(path, catalog)
        return catalog


def _merge_provider_setup(
    existing: ModelCatalog | None,
    setup: ProviderSetup,
    *,
    replace: bool,
) -> ModelCatalog:
    """Merge one collected setup while retaining unrelated models and role assignments.

    Args:
        existing: Existing catalog, or ``None`` for first setup.
        setup: Fully validated collected provider setup.
        replace: Whether unequal unprotected records may be replaced.

    Returns:
        Complete merged catalog with updated build roles.

    Raises:
        ProviderSetupError: A collected record conflicts with preserved or protected state.
    """
    connections = dict(existing.connections) if existing is not None else {}
    models = dict(existing.models) if existing is not None else {}
    roles = existing.roles if existing is not None else ModelRoles()
    proposed_models = {selection.alias: selection.catalog_record() for selection in setup.models}
    protected_aliases = set(roles.candidates)
    protected_aliases.update(
        alias
        for alias in (roles.incumbent, roles.rubric_proposer, roles.teacher)
        if alias is not None
    )

    for selected in setup.connections:
        proposed = selected.catalog_config()
        current = connections.get(selected.name)
        if current is not None and current != proposed and not replace:
            raise ProviderSetupError(
                f"connection {selected.name!r} already differs; rerun with --replace"
            )
        preserved_aliases = tuple(
            alias
            for alias, record in models.items()
            if record.connection == selected.name
            and (alias not in proposed_models or proposed_models[alias] == record)
        )
        if current is not None and current != proposed and preserved_aliases:
            raise ProviderSetupError(
                f"connection {selected.name!r} is used by preserved model aliases "
                f"{', '.join(sorted(preserved_aliases))}; use a new connection name"
            )
        connections[selected.name] = proposed

    for alias, proposed in proposed_models.items():
        current = models.get(alias)
        if current == proposed:
            continue
        if current is not None and current != proposed and not replace:
            raise ProviderSetupError(f"model alias {alias!r} already differs; rerun with --replace")
        if current is not None and current != proposed and alias in protected_aliases:
            raise ProviderSetupError(
                f"model alias {alias!r} is assigned to a router or training role and cannot be "
                "replaced during provider setup"
            )
        models[alias] = proposed

    role_values = roles.model_dump()
    role_values.update(
        world_model=setup.world_model,
        judge=setup.judge,
        embedder=setup.embedder,
        world_model_reasoning_effort=setup.world_model_reasoning_effort,
        judge_reasoning_effort=setup.judge_reasoning_effort,
    )
    catalog = ModelCatalog(
        schema_version=(
            existing.schema_version if existing is not None else MODEL_CATALOG_SCHEMA_VERSION
        ),
        connections=connections,
        models=models,
        roles=ModelRoles.model_validate(role_values),
    )
    embedder = catalog.models[catalog.roles.embedder or ""]
    if embedder.capabilities is None or not embedder.capabilities.supports_embeddings:
        raise ProviderSetupError(
            f"embedder alias {catalog.roles.embedder!r} must declare embedding support"
        )
    return catalog
